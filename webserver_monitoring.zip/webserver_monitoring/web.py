import sys, socket, io


HOST, PORT = '', 8182
# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
# Bind the socket to the port
sock.bind((HOST,PORT))
sock.listen(1000)
print 'starting up on port %s' % PORT
# Listen for incoming connections

while True:
    	# Wait for a connection
    	connection, client_address = sock.accept()
        data = connection.recv(1024)
	#print data   
	filename = data.split()
	#print nama file di terminal
	file1 =filename[1]	
	file2 =file1[1:]
	print file2
        #baca nama file dri browser
	#f= open(file2+".jpg",'r+')
	#imgdata2 = f.read()
	imgdata2 = 'Yes'
	#f.close()
	http_response = "\HTTP/1.1 200 OK \n\n%s"%imgdata2

        # Clean up the connection
	connection.sendall(http_response)
	connection.close()
